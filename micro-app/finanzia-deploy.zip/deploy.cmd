﻿@echo off
echo Installing production dependencies...
call npm ci --only=production
echo Deployment complete!
